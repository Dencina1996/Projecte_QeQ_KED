<!DOCTYPE html>
<html>
<head>
	<title>GANADOR!</title>
	<link rel="stylesheet" type="text/css" href="Win.css">
	<script type="text/javascript" src="Win.js"></script>
</head>
<body onload="LlamarWinner()">
	<canvas id="canvas" class="Fireworks"></canvas>
</body>
</html>