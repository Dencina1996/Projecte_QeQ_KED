function LlamarLoser() {

	setTimeout(Loser,2000);
}

function Loser() {

	alert("Buena suerte la próxima vez :p");
}