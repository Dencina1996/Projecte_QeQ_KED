//FUNCION SELEC COMBOBOX

var valuePelo = document.getElementById("Pelo");
var valueGafas = document.getElementById("Gafas");
var valueSexo = document.getElementById("Sexo");


//FUNCION PREGUNTA COMBOBOX
var countPreguntas=0;
var contador=document.getElementById("contador");
var imagenServer=document.getElementById("ImagenServer");

function preguntaComboBox(){
	if(valuePelo.value==0 && valueGafas.value==0 && valueSexo.value==0){
		document.getElementById("mensaje").innerText = "Selecciona una pregunta.";
	}if(valuePelo.value!=0 && valueGafas.value!=0 || valueGafas.value!=0 && valueSexo.value!=0 ||
		valueSexo.value!=0 && valuePelo.value!=0){
		document.getElementById("mensaje").innerText = "No puedes seleccionar mas de una pregunta a la vez.";
		valuePelo.value=0;
		valueGafas.value=0;
		valueSexo.value=0;
	}if(valuePelo.value!=0 && valueGafas.value==0 && valueSexo.value==0){
		contador.innerText = "Contador de preguntas: "+(countPreguntas+=1);
		if(valuePelo.value=="moreno"){
			if(imagenServer.getAttribute("cabell")=="moreno"){
				document.getElementById("mensaje").innerText = "Si, es moreno.";
			}else if(imagenServer.getAttribute("cabell")!="moreno"){
				document.getElementById("mensaje").innerText = "No, no es moreno.";
			}
		}else if(valuePelo.value=="rubio"){
			if(imagenServer.getAttribute("cabell")=="ros"){
				document.getElementById("mensaje").innerText = "Si, es rubio";
			}else if(imagenServer.getAttribute("cabell")!="ros"){
				document.getElementById("mensaje").innerText = "No, no es rubio.";
			}
		}else if(valuePelo.value=="castaño"){
			if(imagenServer.getAttribute("cabell")=="castany"){
				document.getElementById("mensaje").innerText = "Si, es castaño.";
			}else if(imagenServer.getAttribute("cabell")!="castany"){
				document.getElementById("mensaje").innerText = "No, no es castaño.";
			}
		}valuePelo.value=0;
	}if(valueGafas.value!=0 && valuePelo.value==0 && valueSexo.value==0){
		contador.innerText = "Contador de preguntas: "+(countPreguntas+=1);
		if(valueGafas.value=="gafas"){
			if(imagenServer.getAttribute("ulleres")=="si"){
				document.getElementById("mensaje").innerText = "Si, lleva gafas.";
			}else if(imagenServer.getAttribute("ulleres")!="si"){
				document.getElementById("mensaje").innerText = "No, no lleva gafas.";
			}
		}else if(valueGafas.value=="nogafas"){
			if(imagenServer.getAttribute("ulleres")=="no"){
				document.getElementById("mensaje").innerText = "No, no lleva gafas.";
			}else if(imagenServer.getAttribute("ulleres")!="no"){
				document.getElementById("mensaje").innerText = "Si, lleva gafas.";
			}
		}valueGafas.value=0;
	}if(valueSexo.value!=0 && valuePelo.value==0 && valueGafas.value==0){
		contador.innerText = "Contador de preguntas: "+(countPreguntas+=1);
		if(valueSexo.value=="hombre"){
			if(imagenServer.getAttribute("sexe")=="home\n"){
				document.getElementById("mensaje").innerText = "Si, es un hombre";
			}else if(imagenServer.getAttribute("sexe")!="home\n"){
				document.getElementById("mensaje").innerText = "No, no es un hombre.";
			}
		}else if(valueSexo.value=="mujer"){
			if(imagenServer.getAttribute("sexe")=="dona\n"){
				document.getElementById("mensaje").innerText = "Si, es una mujer.";
			}else if(imagenServer.getAttribute("sexe")!="dona\n"){
				document.getElementById("mensaje").innerText = "No, no es una mujer.";
			}
		}valueSexo.value=0;
	}
}

//ALERT REGISTRAR RECORD
function winner() {
    var registre = confirm("¿Deseas registrar tu record?");
    if(registre == true){
        var person = prompt("Introduce tu nombre de usuario:\n(Mín. 6 caracteres)");
        if(person == null || person == "" || person.length < 6){
            alert("Por favor, introduce un nombre de usuario válido.");
            winner();
        }else{
            alert("¡Enhorabuena "+person+"! Gracias por jugar.");
		}
    }else{
        alert("Lo has hecho muy bien. ENHORABUENA!");
    }
}

//GIRAR CARTAS

var count=0;
var cartaServidor = imagenServer.getAttribute("src");
var arrayElegidas = [];

function girarCarta(card, cardserver){
	count+=1;
	if(card.className == 'flip-card'){
		card.classList.toggle('is-flipped');
		var sonido = new Audio("sonido.mp3");
  		sonido.play();
  		var cartasrc = card.childNodes[0].firstChild.getAttribute("src");
  		arrayElegidas.push(cartasrc);
		if(count==11){
			if(cardserver.className == 'flip-card'){
				cardserver.classList.toggle('is-flipped');
				if(arrayElegidas.includes(cartaServidor)){
					setTimeout(loser,2000);
				}else{
					setTimeout(winner,2000);
					
				}
			}
		}
	}
}

// GANADOR

function winner() {

	window.open("Win.php","_self");
}

function loser() {

	window.open("Lose.php","_self");
}