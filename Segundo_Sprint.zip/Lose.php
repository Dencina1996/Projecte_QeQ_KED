<!DOCTYPE html>
<html>
<head>
	<title>PERDEDOR!</title>
	<link rel="stylesheet" type="text/css" href="Lose.css">
	<script type="text/javascript" src="Lose.js"></script>
</head>
<body onload="LlamarLoser()">
	<h1>¡¡¡PERDEDOR!!!</h1>
</body>
</html>